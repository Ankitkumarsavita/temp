
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>
    <link rel="stylesheet" href="style.css">
    <title>signup</title>
</head>

<body>
    <center>

        <h2>Signup here !</h2>
        <div id="signupMessage" class="alert alert-success" style="display:none;"></div>
        <form action="signup.php" method="POST" enctype='multipart/form-data' id="signupForm" >
            <div class="mb-3">
                <label for="name" class="form-label "></label>
                <input type="text" name="name" class="form-control field" id="name" placeholder="Enter your Name">
                <!-- <p><?php echo $nameError; ?></p> -->
                <span id="sign_name_msg"></span>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label"></label>
                <input type="text" name="email" class="form-control field" id="email" placeholder="Enter your Email">
                <!-- <p><?php echo $emailError; ?></p> -->
                <span id="sign_email_msg"></span>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label"></label>
                <input type="password" name="password" class="form-control field" id="password" placeholder="Enter your Password">
                <!-- <p><?php echo $passError; ?></p> -->
                <span id="sign_password_msg"></span>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label"></label>
                <input type="password" name="confirm_password" class="form-control field" id="confirm_password" placeholder="confirm password">
                <!-- <p><?php echo $confirm_passError  ?></p> -->
                <span id="confirm_password_msg"></span>
            </div>
            <div class="mb-3">
                <label for="formFile" class="form-label"></label>
                <input class="form-control" type="file" id="formFileMultiple" name="uploadfile" id="formFile" accept=".jpg, .jpeg, .png " style="width: 500px; color: black; font-size: 14px;" multiple>
            </div>
            <input type="hidden" name="op" value="signup">
            <input type="button" class="btn btn-primary" name="submit" value="Signup" id="signupbtn"></input>

        </form>
        <p>Already have an account?<a href="index.php">Login</a></p>
    </center>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="signup.js"></script>
</body>

</html>